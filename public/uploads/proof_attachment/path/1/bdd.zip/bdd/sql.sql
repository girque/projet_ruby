DROP TABLE IF EXISTS Personne ;
CREATE TABLE Personne (id_personne INT  AUTO_INCREMENT PRIMARY KEY,
nom VARCHAR(50),
prenom VARCHAR(50),
email VARCHAR(50),
password VARCHAR(250),
date_naissance DATE,
photo VARCHAR(250),
date_inscription DATE);

DROP TABLE IF EXISTS Evenement ;
CREATE TABLE Evenement (id_evenement INT  AUTO_INCREMENT NOT NULL,
libelle VARCHAR(50),
description VARCHAR(500),
adresse VARCHAR(250),
date_debut DATE,
date_fin DATE,
lien_externe INT,
confidentialite SET('public','privé','public_avec_invitation') NOT NULL,
date_creation DATE,
photo_presentation VARCHAR(250),
id_categorie INT NOT NULL,
PRIMARY KEY (id_evenement) );

DROP TABLE IF EXISTS Categorie_evenement ;
CREATE TABLE Categorie_evenement (id_categorie INT  AUTO_INCREMENT NOT NULL,
libelle_categorie VARCHAR(50),
description_categorie VARCHAR(250),
PRIMARY KEY (id_categorie) );

DROP TABLE IF EXISTS Organise ;
CREATE TABLE Organise (id_personne INT  AUTO_INCREMENT NOT NULL,
id_evenement INT NOT NULL,
PRIMARY KEY (id_personne,
 id_evenement) );

DROP TABLE IF EXISTS Participe ;
CREATE TABLE Participe (id_personne INT  AUTO_INCREMENT NOT NULL,
id_evenement INT NOT NULL,
PRIMARY KEY (id_personne,
 id_evenement) );

DROP TABLE IF EXISTS Est_invite ;
CREATE TABLE Est_invite (id_personne INT  AUTO_INCREMENT NOT NULL,
id_evenement INT NOT NULL,
id_personne_invitant INT NOT NULL,
PRIMARY KEY (id_personne,
 id_evenement) );

DROP TABLE IF EXISTS Suit ;
CREATE TABLE Suit (id_personne_suivant INT  AUTO_INCREMENT NOT NULL,
id_personne_suivie INT NOT NULL,
PRIMARY KEY (id_personne_suivant,
 id_personne_suivie) );

ALTER TABLE Evenement ADD CONSTRAINT FK_Evenement_id_categorie FOREIGN KEY (id_categorie) REFERENCES Categorie_evenement (id_categorie);
ALTER TABLE Organise ADD CONSTRAINT FK_Organise_id_personne FOREIGN KEY (id_personne) REFERENCES Personne (id_personne);
ALTER TABLE Organise ADD CONSTRAINT FK_Organise_id_evenement FOREIGN KEY (id_evenement) REFERENCES Evenement (id_evenement);
ALTER TABLE Participe ADD CONSTRAINT FK_Participe_id_personne FOREIGN KEY (id_personne) REFERENCES Personne (id_personne);
ALTER TABLE Participe ADD CONSTRAINT FK_Participe_id_evenement FOREIGN KEY (id_evenement) REFERENCES Evenement (id_evenement);
ALTER TABLE Est_invite ADD CONSTRAINT FK_Est_invite_id_personne FOREIGN KEY (id_personne) REFERENCES Personne (id_personne);
ALTER TABLE Est_invite ADD CONSTRAINT FK_Est_invite_id_personne_invitant FOREIGN KEY (id_personne_invitant) REFERENCES Personne (id_personne);
ALTER TABLE Est_invite ADD CONSTRAINT FK_Est_invite_id_evenement FOREIGN KEY (id_evenement) REFERENCES Evenement (id_evenement);
ALTER TABLE Suit ADD CONSTRAINT FK_Suit_id_personne_suivant FOREIGN KEY (id_personne_suivant) REFERENCES Personne (id_personne);
ALTER TABLE Suit ADD CONSTRAINT FK_Suit_id_personne_suivie FOREIGN KEY (id_personne_suivie) REFERENCES Personne (id_personne);
